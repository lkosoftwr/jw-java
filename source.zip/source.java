package de.leomc.test;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class test {

 public static void main(String[] args){
	 
	 JButton Knopf1 = new JButton("Fortsetzen!");
	 JButton Knopf2 = new JButton("STOP!");
	JFrame Program =
			new JFrame("Jugendweihe");
	Program.setSize(400,300);
	Program.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Program.setVisible (true);
	JPanel Auswahl = new JPanel();
	Auswahl.add (Knopf1);
	Auswahl.add(Knopf2);
	Program.setContentPane(Auswahl);
	Auswahl.setLayout(new GridLayout());
	 
	//Listener(Knopf1)
	Knopf1.addActionListener (new ActionListener(){
	
		

		public void actionPerformed(ActionEvent x) {
Program.setVisible(false);
	int alter =		JOptionPane.showConfirmDialog(null, "Bist du mind. 14 Jahre alt?");
		
			//Abbruch wenn noch nicht 14
			if(alter == 1){
				System.exit(0);
			}
			//Abbruch wenn der Knopf "Abbrechen" gedr�ckt wird
			if(alter == 2){
				System.exit(0);
			}
			//Fortsetzen des Codes wenn der Benutzer 14 ist
			if(alter == 0){
			int Jugendweihe =	JOptionPane.showConfirmDialog(null, "Hattest du schon deine Jugendweihe?");
			if(Jugendweihe == 2){
				System.exit(0);
			}
			
			if(Jugendweihe == 1){
				JOptionPane.showMessageDialog(null, "Dann wirst du sie bald haben!");
			}
			if(Jugendweihe == 0){
				JOptionPane.showMessageDialog(null, "OK!");
			}
			
			
			}
		}
		
		
			});		
		
	//Listener(knopf2)
	 Knopf2.addActionListener(new ActionListener(){
		 
		 public void actionPerformed(ActionEvent x) {
			 System.exit(0);
		 }
		 
	 });
	
	
	
}

	
}
